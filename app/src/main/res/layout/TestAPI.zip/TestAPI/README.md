<br />
<p align="center">
  <h1 align="center">Nutrisee</h1>
  <h2 align="center">
  Image Recognition-based Food Calorie Checker An Automated Tool for Accurate and Efficient Calorie Estimation</h2>
  
  <p align="center">
  This is a project to fulfill the  <a href="https://grow.google/intl/id_id/bangkit/"><strong>Bangkit Academy led by Google, Tokopedia, Gojek, & Traveloka</strong></a>
   Program.
    <br />
    <a href="https://github.com/GJOE27/Capstone-Project-Bangkit"><strong>Explore the docs »</strong></a>
    <br />
    <br />
    © C23 - PS014 Bangkit Capstone Team
  </p>
</p>

# Team Members

## Team ID : C23-PS014

<br>

| Name                      | Student ID  | Path                |
| ------------------------- | ----------- | ------------------- |
| Attar Syifa Kamal         | M151DSX2542 | Machine Learning    |
| Kevin Naufal Eryogia      | M013DSX1585 | Machine Learning    |
| Rizvi Mahendra Dhaneswara | M017DSX2936 | Machine Learning    |
| Evandro Wildan Aqilah     | C038DSX4844 | Cloud Computing     |
| Muhammad Abrar Aldias     | C038DKX4389 | Cloud Computing     |
| Faishal Afif              | A151DKX4311 | Mobile Development  |

<br>
